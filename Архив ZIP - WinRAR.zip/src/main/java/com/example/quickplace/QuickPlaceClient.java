package com.example.quickplace;

import com.example.quickplace.mixin.MinecraftAccessor;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

public class QuickPlaceClient implements ClientModInitializer {

	/** Включён ли мод (переключается клавишей V). */
	private static boolean enabled = true;

	/** Сколько тиков кнопка должна быть зажата, прежде чем включится непрерывная установка (~0.3 с). */
	private static final int HOLD_THRESHOLD_TICKS = 6;

	/** Сколько тиков подряд зажата кнопка установки. */
	private static int holdTicks = 0;

	private static KeyMapping toggleKey;

	@Override
	public void onInitializeClient() {
		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.quickplace.toggle",
				InputConstants.Type.KEYSYM,
				GLFW.GLFW_KEY_V,
				KeyMapping.Category.MISC
		));

		ClientTickEvents.END_CLIENT_TICK.register(QuickPlaceClient::onClientTick);
	}

	private static void onClientTick(Minecraft mc) {
		while (toggleKey.consumeClick()) {
			enabled = !enabled;
			if (mc.player != null) {
				mc.player.displayClientMessage(
						Component.literal("QuickPlace: " + (enabled ? "включён" : "выключен")),
						true
				);
			}
		}

		if (mc.player == null || mc.level == null || mc.gameMode == null) {
			holdTicks = 0;
			return;
		}

		// Работаем только пока зажата кнопка установки и в руке блок
		if (!enabled || !mc.options.keyUse.isDown() || !holdingBlock(mc)) {
			holdTicks = 0;
			return;
		}

		holdTicks++;

		// Первые тики после нажатия не трогаем: один клик ставит ровно один блок.
		// Если кнопка удерживается дольше порога, включается непрерывная установка.
		if (holdTicks < HOLD_THRESHOLD_TICKS) {
			return;
		}

		if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
			return;
		}

		((MinecraftAccessor) (Object) mc).quickplace$setRightClickDelay(0);
	}

	private static boolean holdingBlock(Minecraft mc) {
		return isBlock(mc.player.getMainHandItem()) || isBlock(mc.player.getOffhandItem());
	}

	private static boolean isBlock(ItemStack stack) {
		return !stack.isEmpty() && stack.getItem() instanceof BlockItem;
	}
}
